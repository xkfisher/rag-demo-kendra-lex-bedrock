"""For backwards compatibility."""
from langchain.utilities.python import PythonREPL

__all__ = ["PythonREPL"]
